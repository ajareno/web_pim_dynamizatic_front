import { IdiomaControllerApi, settings } from "@/app/api-nathalie";

const apiIdioma = new IdiomaControllerApi(settings)


export const getIdiomas = async () => {
    const {data: dataIdiomas} = await apiIdioma.idiomaControllerFind()
    return dataIdiomas
}

export const postIdioma = async (objIdioma) => {
    try {
        const {data: dataIdioma} = await apiIdioma.idiomaControllerCreate(objIdioma)
        return dataIdioma

    } catch (error) {
        console.log(error)
    }
}

export const patchIdioma = async (idIdioma, objIdioma) => {
    const {data: dataIdioma} = await apiIdioma.idiomaControllerUpdateById(idIdioma, objIdioma)
    return dataIdioma
}

export const deleteIdioma = async (idIdioma) => {
    const {data: dataIdioma} = await apiIdioma.idiomaControllerDeleteById(idIdioma)
    return dataIdioma
}
