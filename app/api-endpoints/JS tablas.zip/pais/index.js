import { PaisControllerApi, settings } from "@/app/api-nathalie";

const apiPais = new PaisControllerApi(settings)


export const getPaises = async () => {
    const {data: dataPaises} = await apiPais.paisControllerFind()
    return dataPaises
}

export const postPais = async (objPais) => {
    try {
        const {data: dataPais} = await apiPais.paisControllerCreate(objPais)
        return dataPais

    } catch (error) {
        console.log(error)
    }
}

export const patchPais = async (idPais, objPais) => {
    const {data: dataPais} = await apiPais.paisControllerUpdateById(idPais, objPais)
    return dataPais
}

export const deletePais = async (idPais) => {
    const {data: dataPais} = await apiPais.paisControllerDeleteById(idPais)
    return dataPais
}

