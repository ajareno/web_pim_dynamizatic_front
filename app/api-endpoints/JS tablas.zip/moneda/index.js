import { MonedaControllerApi, settings } from "@/app/api-nathalie";

const apiMoneda = new MonedaControllerApi(settings)


export const getMonedas = async () => {
    const {data: dataMonedas} = await apiMoneda.monedaControllerFind()
    return dataMonedas
}

export const postMoneda = async (objMoneda) => {
    const {data: dataMoneda} = await apiMoneda.monedaControllerCreate(objMoneda)
    return dataMoneda
}

export const patchMoneda = async (idMoneda, objMoneda) => {
    const {data: dataMoneda} = await apiMoneda.monedaControllerUpdateById(idMoneda, objMoneda)
    return dataMoneda
}

export const deleteMoneda = async (idMoneda) => {
    const {data: dataMoneda} = await apiMoneda.monedaControllerDeleteById(idMoneda)
    return dataMoneda
}

