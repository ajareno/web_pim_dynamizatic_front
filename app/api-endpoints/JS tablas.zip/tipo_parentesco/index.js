import { TipoParentescoControllerApi, settings } from "@/app/api-nathalie";

const apiTipoParentesco = new TipoParentescoControllerApi(settings)


export const getTipoParentescos = async () => {
    const {data: dataTipoParentescos} = await apiTipoParentesco.tipoParentescoControllerFind()
    return dataTipoParentescos
}

export const postTipoParentesco = async (objTipoParentesco) => {
    const {data: dataTipoParentesco} = await apiTipoParentesco.tipoParentescoControllerCreate(objTipoParentesco)
    return dataTipoParentesco
}

export const patchTipoParentesco = async (idTipoParentesco, objTipoParentesco) => {
    const {data: dataTipoParentesco} = await apiTipoParentesco.tipoParentescoControllerUpdateById(idTipoParentesco, objTipoParentesco)
    return dataTipoParentesco
}

export const deleteTipoParentesco = async (idTipoParentesco) => {
    const {data: dataTipoParentesco} = await apiTipoParentesco.tipoParentescoControllerDeleteById(idTipoParentesco)
    return dataTipoParentesco
}

